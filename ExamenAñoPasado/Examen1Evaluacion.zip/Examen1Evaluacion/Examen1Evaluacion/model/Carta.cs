﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Examen1Evaluacion
{
    public class Carta
    {
        private int _id;
        private Uri _uri;
        private String _nombre;

        public Carta(int id,Uri uri,String nombre)
        {
            this._id = id;
            this._uri = uri;
            this.nombre = nombre;
        }

        public String nombre
        {
            get
            {
                return this._nombre;
            }
            set
            {
                this._nombre = value;
            }
        }

        public int id
        {
            get
            {
                return this._id;
               
            }
            set
            {
                this.id = value;
            }
        }

        public Uri uri
        {
            get
            {
                return this._uri;
            }
            set
            {
                this._uri = value;
            }
        }
    }
}
