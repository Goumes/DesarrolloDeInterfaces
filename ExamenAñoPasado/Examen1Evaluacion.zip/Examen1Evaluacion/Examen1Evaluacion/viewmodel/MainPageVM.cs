﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml;

namespace Examen1Evaluacion
{
    public class MainPageVM:clsVMBase
    {
        

        private ObservableCollection<Carta> _lista;
        private Carta _cartaSeleccionada;
        private Carta _cartaaux;
        private static int cartasSeleccionadas;
        private int parejasencontradas;


        public MainPageVM()
        {
            _lista = new Listado().list;
            cartasSeleccionadas = 0;
            parejasencontradas = 0;

        }

        #region getters&setters
        public Carta cartaSeleccionada
        {
            get
            {
                return this._cartaSeleccionada;
            }
            set
            {
                
                this._cartaSeleccionada = value;

                if (this._cartaSeleccionada !=_cartaaux) {
                    
                    Uri u= this.cambiaFoto(cartaSeleccionada.nombre);

                    cartaSeleccionada.uri = u;
                    ObservableCollection<Carta> caux = new ObservableCollection<Carta>();
                    for (int i = 0; i < this._lista.Count(); i++)
                    {
                        if (lista.ElementAt(i).nombre == cartaSeleccionada.nombre)
                        {

                            lista.ElementAt(i).uri = cartaSeleccionada.uri;
                            caux.Add(lista.ElementAt(i));
                            
                        }
                        else
                        {
                            caux.Add(lista.ElementAt(i));

                        }
 
                    }


                    lista = caux;
                    this.retrasasegundo(null, null);
                    //quiere decir que ha escogido otra carta
                    if (_cartaaux != cartaSeleccionada)
                    {
                        cartasSeleccionadas += 1;
                    }

                    //Si es la segunda carta que selecciona
                    if (cartasSeleccionadas == 2)
                    {
                        if(!this.iguales(cartaSeleccionada, _cartaaux))
                        {
                            ObservableCollection<Carta> caux2 = new ObservableCollection<Carta>();
                            for (int i = 0; i < this._lista.Count(); i++)
                            {
                                if (lista.ElementAt(i).nombre == cartaSeleccionada.nombre)
                                {

                                    lista.ElementAt(i).uri = new Uri("ms-appx://_Examen1Evaluacion/Fotos/logo.png",UriKind.Absolute);
                                    
                                    caux2.Add(lista.ElementAt(i));

                                }else if(lista.ElementAt(i).nombre == _cartaaux.nombre)
                                {
                                    lista.ElementAt(i).uri = new Uri("ms-appx://_Examen1Evaluacion/Fotos/logo.png", UriKind.Absolute);
                                    caux2.Add(lista.ElementAt(i));
                                }
                                else
                                {
                                    caux2.Add(lista.ElementAt(i));

                                }

                            }
                            lista = caux2;
                            
                        }
                        else
                        {
                            parejasencontradas += 1;
                            if (parejasencontradas == 6)
                            {
                                //Toast diciendo que ha ganado
                            }
                        }

                        cartasSeleccionadas = 0;
                    }
                    _cartaaux = cartaSeleccionada;
                }
                
            }
        }



        public Carta cartaaux
        {
            get
            {
                return this._cartaaux;
            }
            set
            {
                this._cartaaux = value;

            }
        }

        public ObservableCollection<Carta> lista
        {
            get
            {
                return this._lista;
            }
            set
            {
                this._lista = value;
                NotifyPropertyChanged("lista");
            }
        }

        #endregion

        /// <summary>
        /// Metodo para cambiar la foto de default a la original
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public Uri cambiaFoto(String nombre)
        {
            Uri uri = null;

            switch (nombre)
            {
                case "AR-15" :
                    uri = new Uri("ms-appx://_Examen1Evaluacion/Fotos/AR-15.jpg", UriKind.Absolute);
                    break;
                case "Ballesta":
                    uri = new Uri("ms-appx://_Examen1Evaluacion/Fotos/Ballesta.jpg", UriKind.Absolute);
                    break;
                case "Colt":
                    uri = new Uri("ms-appx://_Examen1Evaluacion/Fotos/Colt.jpg", UriKind.Absolute);
                    break;
                case "Daryl":
                    uri = new Uri("ms-appx://_Examen1Evaluacion/Fotos/Daryl.jpg", UriKind.Absolute);
                    break;
                case "Katana":
                    uri = new Uri("ms-appx://_Examen1Evaluacion/Fotos/Katana.jpg", UriKind.Absolute);
                    break;
                case "Lucille":
                    uri = new Uri("ms-appx://_Examen1Evaluacion/Fotos/Lucille.jpg", UriKind.Absolute);
                    break;
                case "Martillo":
                    uri = new Uri("ms-appx://_Examen1Evaluacion/Fotos/Martillo.jpg", UriKind.Absolute);
                    break;
                case "Michonne":
                    uri = new Uri("ms-appx://_Examen1Evaluacion/Fotos/Michonne.jpg", UriKind.Absolute);
                    break;
                case "Negan":
                    uri = new Uri("ms-appx://_Examen1Evaluacion/Fotos/Negan.jpg", UriKind.Absolute);
                    break;
                case "Rick":
                    uri = new Uri("ms-appx://_Examen1Evaluacion/Fotos/Rick.jpg", UriKind.Absolute);
                    break;
                case "Sasha":
                    uri = new Uri("ms-appx://_Examen1Evaluacion/Fotos/Sasha.jpg", UriKind.Absolute);
                    break;
                case "Tyreese":
                    uri = new Uri("ms-appx://_Examen1Evaluacion/Fotos/Tyreese.jpg", UriKind.Absolute);
                    break;
            }

            return uri;
           
        }


        /// <summary>
        /// Metodo asincrono que retrasa la instruccion siguiente 1 segundo
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void retrasasegundo(object sender, RoutedEventArgs e)
        {
            await Task.Delay(1000);
        }

        /// <summary>
        /// Metodo que comprueba que los ids sean iguales.
        /// </summary>
        /// <param name="c1"></param>
        /// <param name="c2"></param>
        /// <returns></returns>
        public bool iguales(Carta c1,Carta c2)
        {
            bool igual = false;
            if (c1.id == c2.id)
            {
                igual = true;
            }
            return igual;
        }
    }
}
